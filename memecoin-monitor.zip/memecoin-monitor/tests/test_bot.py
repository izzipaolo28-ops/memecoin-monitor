import dataclasses

from conftest import POOL, QUOTE, TOKEN, FakeReader, FakeWatcher, RecordingSink, make_event

from memecoin_monitor.bot import Bot
from memecoin_monitor.executor import PaperExecutor
from memecoin_monitor.models import TokenInfo


def make_bot(cfg, reader, decide_fn, batches, clock=None):
    sink = RecordingSink()
    executor = PaperExecutor(0.05, cfg.data_dir / "positions.json")
    kwargs = {"clock": clock} if clock else {}
    return Bot(cfg, reader, FakeWatcher(batches), decide_fn, executor, sink, **kwargs), sink, executor


BUY = lambda s: {"action": "buy", "confidence": 0.95}


def test_buy_opens_paper_position(cfg):
    bot, sink, ex = make_bot(cfg, FakeReader(), BUY, [[make_event()]])
    bot.step()
    (pos,) = ex.open_positions()
    # quote=token0, base=token1; 1e7 token1 per token0 -> 1e-7 quote per base
    assert pos.entry_price == 1e-7 and pos.symbol == "MEME" and pos.quote_symbol == "WETH"
    rec = sink.launches[-1]
    assert (rec.status, rec.final_action, rec.model_action) == ("decided", "buy", "buy")
    assert any(a.kind == "BUY" for a in sink.actions)
    assert (cfg.data_dir / "actions.jsonl").exists()


def test_guard_downgrades_low_confidence_buy(cfg):
    bot, sink, ex = make_bot(cfg, FakeReader(), lambda s: {"action": "buy", "confidence": 0.3}, [[make_event()]])
    bot.step()
    rec = sink.launches[-1]
    assert rec.model_action == "buy" and rec.final_action == "skip" and "confidence" in rec.note
    assert ex.open_positions() == []


def test_stub_decide_never_trades(cfg):
    from memecoin_monitor.decision import stub_decide

    bot, sink, ex = make_bot(cfg, FakeReader(), stub_decide, [[make_event()]])
    bot.step()
    assert sink.launches[-1].final_action == "skip" and ex.open_positions() == []


def test_decide_exception_is_contained(cfg):
    def boom(s):
        raise RuntimeError("model down")

    bot, sink, ex = make_bot(cfg, FakeReader(), boom, [[make_event()]])
    bot.step()
    assert sink.launches[-1].final_action == "skip"
    assert any(a.kind == "ERROR" and "model down" in a.text for a in sink.actions)


def test_uninitialized_pool_waits_then_decides(cfg):
    bot, sink, ex = make_bot(cfg, FakeReader(init_after=2), BUY, [[make_event()]])
    bot.step()
    assert sink.launches[-1].status == "pending" and ex.open_positions() == []
    bot.step()
    assert sink.launches[-1].status == "pending"
    bot.step()
    assert sink.launches[-1].status == "decided" and len(ex.open_positions()) == 1


def test_pending_pool_expires(cfg):
    cfg = dataclasses.replace(cfg, pending_max_age=60.0)
    now = [0.0]
    bot, sink, ex = make_bot(cfg, FakeReader(init_after=10**6), BUY, [[make_event()]], clock=lambda: now[0])
    bot.step()
    assert sink.launches[-1].status == "pending"
    now[0] = 61.0
    bot.step()
    rec = sink.launches[-1]
    assert rec.status == "expired" and rec.final_action == "skip" and not bot._pending


def test_token_without_bytecode_skips_without_calling_model(cfg):
    reader = FakeReader()
    reader.tokens[TOKEN] = TokenInfo(TOKEN, False)
    calls = []
    bot, sink, ex = make_bot(cfg, reader, lambda s: calls.append(s) or BUY(s), [[make_event()]])
    bot.step()
    assert calls == [] and sink.launches[-1].final_action == "skip"


def test_unknown_quote_token_blocks_buy(cfg):
    cfg = dataclasses.replace(cfg, quote_tokens=())
    bot, sink, ex = make_bot(cfg, FakeReader(), BUY, [[make_event()]])
    bot.step()
    assert sink.launches[-1].final_action == "skip" and "QUOTE_TOKENS" in sink.launches[-1].note


def test_positions_marked_to_market(cfg):
    reader = FakeReader()
    bot, sink, ex = make_bot(cfg, reader, BUY, [[make_event()]])
    bot.step()
    reader.price_t1_per_t0 = 5e6  # memecoin doubles in quote terms (2e-7)
    bot.step()
    assert ex.open_positions()[0].pnl_pct == 100.0
