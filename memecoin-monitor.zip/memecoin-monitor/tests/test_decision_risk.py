import pytest

from memecoin_monitor.config import Config
from memecoin_monitor.decision import DecisionError, safe_decide, stub_decide, validate_decision
from memecoin_monitor.risk import apply_guards, score_state


def state(**over):
    s = {
        "base_token": {"has_code": True, "owner_status": "renounced", "decimals": 18,
                       "total_supply_raw": "1000", "symbol": "MEME"},
        "quote_known": True, "liquidity_quote": 5.0, "price": 1e-7,
        "thresholds": {"min_liquidity": 1.0},
    }
    s.update(over)
    s["risk_score"], s["risk_flags"] = score_state(s)
    return s


def test_stub_skips():
    assert stub_decide({}) == {"action": "skip", "confidence": 0.0}


def test_decide_without_api_key_falls_back_to_skip(monkeypatch):
    from memecoin_monitor.decision import decide

    monkeypatch.delenv("JEV_API_KEY", raising=False)
    decision, err = safe_decide({}, decide)
    assert decision == {"action": "skip", "confidence": 0.0} and "JEV_API_KEY" in err


@pytest.mark.parametrize("bad", [None, "buy", {"action": "yolo", "confidence": 1}, {"action": "buy"},
                                 {"action": "buy", "confidence": float("nan")}, {"action": "buy", "confidence": True}])
def test_validate_rejects(bad):
    with pytest.raises(DecisionError):
        validate_decision(bad)


def test_validate_clamps_confidence():
    assert validate_decision({"action": "buy", "confidence": 7})["confidence"] == 1.0


def test_safe_decide_swallows_errors():
    def boom(_):
        raise RuntimeError("model down")

    decision, err = safe_decide({}, boom)
    assert decision == {"action": "skip", "confidence": 0.0} and "model down" in err


def test_clean_state_scores_zero():
    assert state()["risk_score"] == 0


def test_risky_state_flags():
    s = state(liquidity_quote=0.1, base_token={**state()["base_token"], "owner_status": "owned"})
    assert {"owner_not_renounced", "low_liquidity"} <= set(s["risk_flags"])
    assert s["risk_score"] == 50


def test_no_bytecode_is_max_risk():
    assert state(base_token={**state()["base_token"], "has_code": False})["risk_score"] >= 100


CFG = Config(min_liquidity=1.0, min_confidence=0.7, max_risk_score=50.0)
BUY = {"action": "buy", "confidence": 0.9}


def test_guard_passes_good_buy():
    assert apply_guards(BUY, state(), CFG).action == "buy"


def test_guard_blocks_low_confidence():
    r = apply_guards({"action": "buy", "confidence": 0.5}, state(), CFG)
    assert r.action == "skip" and "confidence" in r.reasons[0]


def test_guard_blocks_low_liquidity_unknown_quote_and_risk():
    assert apply_guards(BUY, state(liquidity_quote=0.2), CFG).action == "skip"
    assert apply_guards(BUY, state(quote_known=False), CFG).action == "skip"
    risky = state(liquidity_quote=0.2, base_token={**state()["base_token"], "owner_status": "owned", "decimals": None})
    assert any("risk" in r for r in apply_guards(BUY, risky, CFG).reasons)


def test_guard_leaves_hold_and_skip_alone():
    assert apply_guards({"action": "hold", "confidence": 0.1}, state(liquidity_quote=0), CFG).action == "hold"
