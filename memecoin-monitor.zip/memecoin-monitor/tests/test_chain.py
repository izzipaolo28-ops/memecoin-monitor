from decimal import Decimal

import pytest
from eth_abi import encode
from eth_utils import keccak, to_checksum_address
from web3 import Web3

from memecoin_monitor.chain import (
    POOL_CREATED_SIG,
    ChainError,
    ChainReader,
    PoolWatcher,
    _decode_text,
    sqrt_price_x96_to_price,
)
from memecoin_monitor.config import Config
from memecoin_monitor.models import PoolCreated, PoolPrice

T0 = to_checksum_address("0x" + "11" * 20)
T1 = to_checksum_address("0x" + "22" * 20)
POOL = to_checksum_address("0x" + "33" * 20)


def reader():
    return ChainReader(Config(), w3=Web3(Web3.HTTPProvider("http://127.0.0.1:1")))


def pool_created_log(block=10, idx=3):
    topic0 = keccak(text=POOL_CREATED_SIG)
    pad = lambda addr: bytes.fromhex(addr[2:]).rjust(32, b"\x00")
    return {
        "address": Config().factory_address,
        "blockHash": b"\x01" * 32,
        "blockNumber": block,
        "data": encode(["int24", "address"], [60, POOL]),
        "logIndex": idx,
        "removed": False,
        "topics": [topic0, pad(T0), pad(T1), (3000).to_bytes(32, "big")],
        "transactionHash": b"\x02" * 32,
        "transactionIndex": 0,
    }


def test_price_equal_decimals():
    assert sqrt_price_x96_to_price(2**96, 18, 18) == Decimal(1)


def test_price_decimal_adjustment():
    # token0 = 18 dec, token1 = 6 dec, 2000 token1 per token0
    sqrt = int((2000 * 10 ** (6 - 18)) ** 0.5 * 2**96)
    price = sqrt_price_x96_to_price(sqrt, 18, 6)
    assert float(price) == pytest.approx(2000, rel=1e-9)


def test_price_uninitialized():
    assert sqrt_price_x96_to_price(0, 18, 18) is None


def test_quote_per_base_orientation():
    p = PoolPrice(1, 0, 4.0)  # 4 token1 per token0
    assert p.quote_per_base(base_is_token0=True) == 4.0
    assert p.quote_per_base(base_is_token0=False) == 0.25
    assert PoolPrice(0, 0, None).quote_per_base(True) is None


def test_decode_pool_created_event(monkeypatch):
    r = reader()
    monkeypatch.setattr(r, "_get_logs_split", lambda a, b: [pool_created_log()])
    (ev,) = r.get_pool_created_events(1, 20)
    assert (ev.pool, ev.token0, ev.token1) == (POOL, T0, T1)
    assert (ev.fee, ev.tick_spacing, ev.block_number, ev.log_index) == (3000, 60, 10, 3)
    assert ev.tx_hash == "0x" + "02" * 32


def test_token_reads(monkeypatch):
    r = reader()
    word = lambda n: n.to_bytes(32, "big")
    owner_word = bytes(12) + bytes.fromhex("dead".rjust(40, "0"))
    replies = {
        "symbol": encode(["string"], ["MEME"]),
        "name": encode(["string"], ["Meme\x1b[31mCoin"]),  # control char must be stripped
        "decimals": word(9),
        "totalSupply": word(1_000),
        "owner": owner_word,
    }
    from memecoin_monitor import chain

    by_sel = {
        chain.SEL_SYMBOL: "symbol", chain.SEL_NAME: "name", chain.SEL_DECIMALS: "decimals",
        chain.SEL_TOTAL_SUPPLY: "totalSupply", chain.SEL_OWNER: "owner",
    }
    monkeypatch.setattr(r, "_get_code", lambda a: b"\x60\x80")
    monkeypatch.setattr(r, "_eth_call", lambda to, data: replies[by_sel[bytes(data[:4])]])
    info = r.read_token(T0)
    assert info.has_code and info.symbol == "MEME" and info.decimals == 9 and info.total_supply == 1000
    assert info.owner_status == "renounced"
    assert "\x1b" not in info.name
    assert info.total_supply_normalized == pytest.approx(1000 / 10**9)


def test_token_without_bytecode(monkeypatch):
    r = reader()
    monkeypatch.setattr(r, "_get_code", lambda a: b"")
    info = r.read_token(T0)
    assert info.has_code is False and info.total_supply is None


def test_owner_status_variants(monkeypatch):
    r = reader()
    live_owner = bytes(12) + bytes.fromhex("ab" * 20)
    monkeypatch.setattr(r, "_eth_call", lambda to, data: live_owner)
    assert r.get_owner_status(T0)[0] == "owned"
    monkeypatch.setattr(r, "_eth_call", lambda to, data: bytes(32))
    assert r.get_owner_status(T0)[0] == "renounced"
    monkeypatch.setattr(r, "_eth_call", lambda to, data: None)
    assert r.get_owner_status(T0) == ("no_owner_function", None)


def test_read_pool_price_decodes_slot0(monkeypatch):
    r = reader()
    raw = encode(["uint160", "int24", "uint16", "uint16", "uint16", "uint8", "bool"], [2**96, -5, 1, 1, 1, 0, True])
    monkeypatch.setattr(r, "_eth_call", lambda to, data: raw)
    p = r.read_pool_price(POOL, 18, 18)
    assert p.initialized and p.tick == -5 and p.price_token1_per_token0 == pytest.approx(1.0)


def test_bytes32_symbol_fallback():
    assert _decode_text(b"MKR".ljust(32, b"\x00")) == "MKR"
    assert _decode_text(None) is None


class StubReader:
    def __init__(self, latest, fail_on=None):
        self.latest, self.fail_on, self.calls = latest, fail_on, []

    def latest_block(self):
        return self.latest

    def get_pool_created_events(self, a, b):
        self.calls.append((a, b))
        if self.fail_on == (a, b):
            raise ChainError("boom")
        return [PoolCreated(POOL, T0, T1, 3000, 60, a, "0x00", 0)]


def test_watcher_starts_at_tip_and_chunks():
    stub = StubReader(latest=10)
    w = PoolWatcher(stub, from_block=None, max_range=4)
    assert [e.block_number for e in w.poll()] == [10]
    stub.latest = 20
    w.poll()
    assert stub.calls == [(10, 10), (11, 14), (15, 18), (19, 20)]


def test_watcher_cursor_not_advanced_past_failure():
    stub = StubReader(latest=12, fail_on=(9, 12))
    w = PoolWatcher(stub, from_block=5, max_range=4)
    got = w.poll()  # chunks (5,8) ok, (9,12) fails -> partial result returned
    assert [e.block_number for e in got] == [5]
    stub.fail_on = None
    assert [e.block_number for e in w.poll()] == [9]  # resumes exactly where it stopped
