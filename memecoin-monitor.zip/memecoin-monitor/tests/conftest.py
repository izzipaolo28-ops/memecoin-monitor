import pytest

from memecoin_monitor.config import Config
from memecoin_monitor.models import PoolCreated, PoolPrice, TokenInfo

QUOTE = "0x" + "00" * 19 + "01"
TOKEN = "0x" + "00" * 19 + "02"
POOL = "0x" + "00" * 19 + "03"


def make_event(pool=POOL, token0=QUOTE, token1=TOKEN):
    return PoolCreated(pool, token0, token1, 3000, 60, 100, "0x" + "ab" * 32, 0)


class FakeReader:
    """Scriptable reader. Quote (QUOTE) is token0, memecoin (TOKEN) is token1."""

    def __init__(self, tokens=None, init_after=0, liquidity=5.0):
        self.tokens = tokens or {
            QUOTE: TokenInfo(QUOTE, True, "WETH", "Wrapped Ether", 18, 10**24, "no_owner_function"),
            TOKEN: TokenInfo(TOKEN, True, "MEME", "Meme", 18, 10**27, "renounced"),
        }
        self.init_after = init_after
        self.liquidity = liquidity
        self.price_reads = 0
        self.price_t1_per_t0 = 1e7  # 1 WETH buys 1e7 MEME -> 1e-7 WETH per MEME

    def latest_block(self):
        return 100

    def read_token(self, address):
        return self.tokens[address]

    def read_pool_price(self, pool, d0, d1):
        self.price_reads += 1
        if self.price_reads <= self.init_after:
            return PoolPrice(0, 0, None)
        return PoolPrice(1, 0, self.price_t1_per_t0)

    def read_pool_liquidity(self, pool):
        return 10**18

    def read_token_balance(self, token, holder):
        return int(self.liquidity * 10**18)


class FakeWatcher:
    def __init__(self, batches):
        self.batches = list(batches)
        self.last_block = 100

    def poll(self):
        return self.batches.pop(0) if self.batches else []


class RecordingSink:
    def __init__(self):
        from memecoin_monitor.sinks import Sink

        self.launches, self.actions, self.errors = [], [], []
        self.base = Sink

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return None

    def launch(self, record):
        self.launches.append(record)

    def action(self, entry):
        self.actions.append(entry)

    def positions(self, positions):
        self.last_positions = positions

    def status(self, **fields):
        if "error" in fields:
            self.errors.append(fields["error"])


@pytest.fixture
def cfg(tmp_path):
    return Config(quote_tokens=(QUOTE,), data_dir=tmp_path, min_liquidity=1.0, min_confidence=0.7, max_risk_score=50.0)
