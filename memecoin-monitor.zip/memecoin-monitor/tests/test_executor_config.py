import json

import pytest

from memecoin_monitor.config import Config, ConfigError
from memecoin_monitor.executor import LiveExecutor, PaperExecutor, SwapRequest

STATE = {
    "price": 2e-7,
    "pool": {"address": "0xPOOL", "base_is_token0": False, "token0_decimals": 18, "token1_decimals": 18},
    "base_token": {"address": "0xBASE", "symbol": "MEME"},
    "quote_token": {"address": "0xQUOTE", "symbol": "WETH"},
}
BUY = {"action": "buy", "confidence": 0.9}


def test_paper_buy_records_position(tmp_path):
    ex = PaperExecutor(0.1, tmp_path / "positions.json")
    pos = ex.execute(STATE, BUY)
    assert pos.entry_price == 2e-7 and pos.size_quote == 0.1
    assert pos.quantity == pytest.approx(0.1 / 2e-7) and pos.entry_time.endswith("+00:00")
    saved = json.loads((tmp_path / "positions.json").read_text())
    assert saved[0]["symbol"] == "MEME" and saved[0]["paper"] is True


def test_paper_blocks_duplicates_and_missing_price(tmp_path):
    ex = PaperExecutor(0.1, tmp_path / "p.json")
    assert ex.execute(STATE, BUY) is not None
    assert ex.execute(STATE, BUY) is None
    assert ex.execute({**STATE, "price": None, "pool": {**STATE["pool"], "address": "0xOTHER"}}, BUY) is None


def test_positions_reload_and_mark_to_market(tmp_path):
    path = tmp_path / "p.json"
    ex = PaperExecutor(0.1, path)
    pos = ex.execute(STATE, BUY)
    ex.update_price(pos.id, 4e-7)
    ex.save()
    (reloaded,) = PaperExecutor(0.1, path).open_positions()
    assert reloaded.pnl_pct == pytest.approx(100.0)


def test_corrupt_positions_file_is_set_aside(tmp_path):
    path = tmp_path / "p.json"
    path.write_text("{not json")
    assert PaperExecutor(0.1, path).open_positions() == []
    assert (tmp_path / "p.bad").exists()


def test_real_swap_is_a_stub():
    with pytest.raises(NotImplementedError):
        LiveExecutor().swap(SwapRequest("p", "a", "b", 1.0, 1.0))
    with pytest.raises(NotImplementedError):
        LiveExecutor().execute(STATE, BUY)


def clear(monkeypatch):
    for k in ("RPC_URL", "CHAIN_ID", "UNISWAP_V3_FACTORY", "POLL_INTERVAL_SECONDS", "QUOTE_TOKENS", "MIN_LIQUIDITY",
              "MIN_CONFIDENCE", "MAX_RISK_SCORE", "MODE", "PAPER_POSITION_SIZE", "DATA_DIR", "MAX_BLOCK_RANGE",
              "PENDING_MAX_AGE_SECONDS"):
        monkeypatch.delenv(k, raising=False)


def test_config_defaults_and_overrides(monkeypatch, tmp_path):
    clear(monkeypatch)
    cfg = Config.from_env(str(tmp_path / "missing.env"))
    assert cfg.chain_id == 4663 and cfg.min_confidence == 0.7 and cfg.quote_tokens == ()
    monkeypatch.setenv("MIN_CONFIDENCE", "0.9")
    monkeypatch.setenv("MIN_LIQUIDITY", "2.5")
    monkeypatch.setenv("QUOTE_TOKENS", "0x" + "00" * 19 + "01, 0x" + "00" * 19 + "02")
    cfg = Config.from_env(str(tmp_path / "missing.env"))
    assert cfg.min_confidence == 0.9 and cfg.min_liquidity == 2.5 and len(cfg.quote_tokens) == 2


@pytest.mark.parametrize("name,value", [("MIN_CONFIDENCE", "1.5"), ("MAX_RISK_SCORE", "abc"), ("MODE", "live"),
                                        ("QUOTE_TOKENS", "0x123"), ("RPC_URL", "ftp://x"), ("POLL_INTERVAL_SECONDS", "0")])
def test_config_rejects_bad_values(monkeypatch, tmp_path, name, value):
    clear(monkeypatch)
    monkeypatch.setenv(name, value)
    with pytest.raises(ConfigError):
        Config.from_env(str(tmp_path / "missing.env"))
