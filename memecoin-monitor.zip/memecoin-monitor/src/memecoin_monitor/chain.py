"""Chain reader: Uniswap V3 pool-creation watcher plus ERC-20 / pool reads for Robinhood Chain.

All reads use raw ``eth_call`` so one code path handles reverts, missing functions and
non-standard tokens (e.g. bytes32 symbols). Transport errors are retried and then raised
as :class:`ChainError`; reverts / empty returns come back as ``None``.
"""
from __future__ import annotations

import logging
import time
from decimal import Decimal, localcontext
from typing import Callable, Iterator, Protocol

import requests
from eth_abi import decode as abi_decode
from eth_abi import encode as abi_encode
from eth_utils import keccak, to_checksum_address
from web3 import Web3
from web3.exceptions import ContractLogicError

from .config import Config
from .models import PoolCreated, PoolPrice, TokenInfo

log = logging.getLogger(__name__)

POOL_CREATED_SIG = "PoolCreated(address,address,uint24,int24,address)"

FACTORY_ABI = [
    {
        "anonymous": False,
        "name": "PoolCreated",
        "type": "event",
        "inputs": [
            {"indexed": True, "name": "token0", "type": "address"},
            {"indexed": True, "name": "token1", "type": "address"},
            {"indexed": True, "name": "fee", "type": "uint24"},
            {"indexed": False, "name": "tickSpacing", "type": "int24"},
            {"indexed": False, "name": "pool", "type": "address"},
        ],
    }
]


def _sel(signature: str) -> bytes:
    return keccak(text=signature)[:4]


SEL_NAME = _sel("name()")
SEL_SYMBOL = _sel("symbol()")
SEL_DECIMALS = _sel("decimals()")
SEL_TOTAL_SUPPLY = _sel("totalSupply()")
SEL_OWNER = _sel("owner()")
SEL_BALANCE_OF = _sel("balanceOf(address)")
SEL_SLOT0 = _sel("slot0()")
SEL_LIQUIDITY = _sel("liquidity()")
SEL_TOKEN0 = _sel("token0()")
SEL_TOKEN1 = _sel("token1()")

SLOT0_TYPES = ["uint160", "int24", "uint16", "uint16", "uint16", "uint8", "bool"]
RENOUNCED_OWNERS = {0, 0xDEAD}  # zero address and the conventional dead address

_TRANSIENT = (requests.exceptions.RequestException, TimeoutError, ConnectionError)
_RANGE_HINTS = ("range", "limit", "too many", "exceed", "more than", "10000")
MAX_TEXT_LEN = 32


class ChainError(RuntimeError):
    """RPC / decoding failure the caller may retry."""


def sqrt_price_x96_to_price(sqrt_price_x96: int, token0_decimals: int, token1_decimals: int) -> Decimal | None:
    """Price of token0 in token1, adjusted for decimals. None if the pool is uninitialized."""
    if sqrt_price_x96 <= 0:
        return None
    with localcontext() as ctx:
        ctx.prec = 80
        ratio = Decimal(sqrt_price_x96) ** 2 / Decimal(2**192)
        return ratio * Decimal(10) ** (token0_decimals - token1_decimals)


def _is_revert(exc: Exception) -> bool:
    if isinstance(exc, ContractLogicError):
        return True
    text = str(exc).lower()
    return "revert" in text or "invalid opcode" in text or "execution error" in text


def _clean_text(value: str) -> str | None:
    """Token names/symbols are attacker-controlled: drop control chars and cap the length."""
    cleaned = "".join(ch for ch in value if ch.isprintable()).strip()
    return cleaned[:MAX_TEXT_LEN] or None


def _decode_text(raw: bytes | None) -> str | None:
    if not raw:
        return None
    try:
        return _clean_text(abi_decode(["string"], raw)[0])
    except Exception:
        if len(raw) == 32:  # legacy bytes32 name/symbol
            return _clean_text(raw.rstrip(b"\x00").decode("utf-8", errors="replace"))
        return None


class Reader(Protocol):
    """What the bot needs from a chain backend (ChainReader, DemoReader, or another chain)."""

    def latest_block(self) -> int: ...
    def read_token(self, address: str) -> TokenInfo: ...
    def read_pool_price(self, pool: str, token0_decimals: int, token1_decimals: int) -> PoolPrice: ...
    def read_pool_liquidity(self, pool: str) -> int | None: ...
    def read_token_balance(self, token: str, holder: str) -> int | None: ...


class Watcher(Protocol):
    last_block: int | None

    def poll(self) -> list[PoolCreated]: ...


class ChainReader:
    RETRIES = 3
    BACKOFF = 0.5

    def __init__(self, config: Config, w3: Web3 | None = None):
        self.cfg = config
        self.w3 = w3 or Web3(Web3.HTTPProvider(config.rpc_url, request_kwargs={"timeout": 15}))
        self.factory = to_checksum_address(config.factory_address)
        self._factory = self.w3.eth.contract(address=self.factory, abi=FACTORY_ABI)
        self.pool_created_topic = Web3.to_hex(keccak(text=POOL_CREATED_SIG))
        self._decimals_cache: dict[str, int] = {}

    # ---- low-level -------------------------------------------------------------------------
    def _rpc(self, fn: Callable, *args, **kwargs):
        last: Exception | None = None
        for attempt in range(self.RETRIES):
            try:
                return fn(*args, **kwargs)
            except _TRANSIENT as exc:
                last = exc
                log.debug("transient RPC error (attempt %d): %s", attempt + 1, exc)
                time.sleep(self.BACKOFF * 2**attempt)
        raise ChainError(f"RPC failed after {self.RETRIES} attempts: {last}") from last

    def _eth_call(self, to: str, data: bytes) -> bytes | None:
        """Returns None on revert / empty return (no code, missing function)."""
        try:
            out = self._rpc(self.w3.eth.call, {"to": to_checksum_address(to), "data": Web3.to_hex(data)})
        except ChainError:
            raise
        except Exception as exc:
            if _is_revert(exc):
                return None
            raise ChainError(f"eth_call to {to} failed: {exc}") from exc
        out = bytes(out)
        return out or None

    def _get_code(self, address: str) -> bytes:
        return bytes(self._rpc(self.w3.eth.get_code, to_checksum_address(address)))

    def _get_logs_split(self, start: int, end: int, depth: int = 0) -> list:
        flt = {"fromBlock": start, "toBlock": end, "address": self.factory, "topics": [self.pool_created_topic]}
        try:
            return list(self._rpc(self.w3.eth.get_logs, flt))
        except ChainError:
            raise
        except Exception as exc:
            if end > start and depth < 12 and any(h in str(exc).lower() for h in _RANGE_HINTS):
                mid = (start + end) // 2
                return self._get_logs_split(start, mid, depth + 1) + self._get_logs_split(mid + 1, end, depth + 1)
            raise ChainError(f"eth_getLogs {start}-{end} failed: {exc}") from exc

    def _call_uint(self, address: str, selector: bytes) -> int | None:
        raw = self._eth_call(address, selector)
        if raw is None or len(raw) < 32:
            return None
        return int.from_bytes(raw[:32], "big")

    # ---- connection ------------------------------------------------------------------------
    def latest_block(self) -> int:
        return int(self._rpc(lambda: self.w3.eth.block_number))

    def verify_connection(self) -> int:
        """Check chain ID and factory bytecode; returns the latest block number."""
        chain_id = int(self._rpc(lambda: self.w3.eth.chain_id))
        if chain_id != self.cfg.chain_id:
            raise ChainError(f"RPC reports chain ID {chain_id}, expected {self.cfg.chain_id} (wrong RPC_URL?)")
        if not self.has_bytecode(self.factory):
            raise ChainError(f"no contract code at factory {self.factory} on chain {chain_id}")
        return self.latest_block()

    # ---- 1. PoolCreated events -------------------------------------------------------------
    def get_pool_created_events(self, from_block: int, to_block: int) -> list[PoolCreated]:
        events: list[PoolCreated] = []
        for log_entry in self._get_logs_split(from_block, to_block):
            try:
                ev = self._factory.events.PoolCreated().process_log(log_entry)
            except Exception as exc:  # malformed / mismatched log: skip, don't crash the watcher
                log.warning("could not decode PoolCreated log: %s", exc)
                continue
            args = ev["args"]
            events.append(
                PoolCreated(
                    pool=to_checksum_address(args["pool"]),
                    token0=to_checksum_address(args["token0"]),
                    token1=to_checksum_address(args["token1"]),
                    fee=int(args["fee"]),
                    tick_spacing=int(args["tickSpacing"]),
                    block_number=int(ev["blockNumber"]),
                    tx_hash=Web3.to_hex(ev["transactionHash"]),
                    log_index=int(ev["logIndex"]),
                )
            )
        events.sort(key=lambda e: (e.block_number, e.log_index))
        return events

    def make_watcher(self, from_block: int | None = None) -> "PoolWatcher":
        return PoolWatcher(self, from_block=from_block, max_range=self.cfg.max_block_range)

    # ---- 2. ERC-20 reads -------------------------------------------------------------------
    def has_bytecode(self, address: str) -> bool:
        return len(self._get_code(address)) > 0

    def get_total_supply(self, token: str) -> int | None:
        return self._call_uint(token, SEL_TOTAL_SUPPLY)

    def get_decimals(self, token: str) -> int | None:
        addr = to_checksum_address(token)
        if addr in self._decimals_cache:
            return self._decimals_cache[addr]
        value = self._call_uint(addr, SEL_DECIMALS)
        if value is None or value > 36:
            return None
        self._decimals_cache[addr] = value
        return value

    def get_owner_status(self, token: str) -> tuple[str, str | None]:
        """('renounced'|'owned'|'no_owner_function', owner_address_or_None) via Ownable.owner()."""
        raw = self._eth_call(token, SEL_OWNER)
        if raw is None or len(raw) < 32:
            return "no_owner_function", None
        owner_int = int.from_bytes(raw[12:32], "big")
        if owner_int in RENOUNCED_OWNERS:
            return "renounced", to_checksum_address(raw[12:32])
        return "owned", to_checksum_address(raw[12:32])

    def read_token(self, address: str) -> TokenInfo:
        addr = to_checksum_address(address)
        if not self.has_bytecode(addr):
            return TokenInfo(address=addr, has_code=False)
        status, owner = self.get_owner_status(addr)
        return TokenInfo(
            address=addr,
            has_code=True,
            symbol=_decode_text(self._eth_call(addr, SEL_SYMBOL)),
            name=_decode_text(self._eth_call(addr, SEL_NAME)),
            decimals=self.get_decimals(addr),
            total_supply=self.get_total_supply(addr),
            owner_status=status,
            owner=owner,
        )

    def read_token_balance(self, token: str, holder: str) -> int | None:
        raw = self._eth_call(token, SEL_BALANCE_OF + abi_encode(["address"], [to_checksum_address(holder)]))
        if raw is None or len(raw) < 32:
            return None
        return int.from_bytes(raw[:32], "big")

    # ---- 3. Pool reads ---------------------------------------------------------------------
    def read_pool_price(self, pool: str, token0_decimals: int, token1_decimals: int) -> PoolPrice:
        raw = self._eth_call(pool, SEL_SLOT0)
        if raw is None:
            raise ChainError(f"slot0() reverted or returned nothing for {pool}")
        try:
            sqrt_price, tick, *_ = abi_decode(SLOT0_TYPES, raw)
        except Exception as exc:
            raise ChainError(f"could not decode slot0() for {pool}: {exc}") from exc
        price = sqrt_price_x96_to_price(sqrt_price, token0_decimals, token1_decimals)
        return PoolPrice(int(sqrt_price), int(tick), float(price) if price is not None else None)

    def read_pool_tokens(self, pool: str) -> tuple[str, str]:
        out = []
        for sel in (SEL_TOKEN0, SEL_TOKEN1):
            raw = self._eth_call(pool, sel)
            if raw is None or len(raw) < 32:
                raise ChainError(f"{pool} does not look like a Uniswap V3 pool")
            out.append(to_checksum_address(raw[12:32]))
        return out[0], out[1]

    def read_pool_price_auto(self, pool: str) -> PoolPrice:
        """Like read_pool_price, but looks up token0/token1 and their decimals itself (defaults to 18)."""
        t0, t1 = self.read_pool_tokens(pool)
        return self.read_pool_price(pool, self.get_decimals(t0) or 18, self.get_decimals(t1) or 18)

    def read_pool_liquidity(self, pool: str) -> int | None:
        """In-range liquidity L (not a USD figure). None if the call fails."""
        return self._call_uint(pool, SEL_LIQUIDITY)


class PoolWatcher:
    """Polls the factory for new PoolCreated events, tracking a block cursor.

    ``from_block=None`` starts at the current tip (no backfill). The cursor only advances past
    chunks that were fetched successfully, so a failed poll never skips events.
    """

    def __init__(self, reader: ChainReader, from_block: int | None = None, max_range: int = 2000):
        self._reader = reader
        self._cursor = from_block
        self._max_range = max(1, max_range)
        self.last_block: int | None = None

    def poll(self) -> list[PoolCreated]:
        latest = self._reader.latest_block()
        self.last_block = latest
        if self._cursor is None:
            self._cursor = latest
        out: list[PoolCreated] = []
        start = self._cursor
        while start <= latest:
            end = min(start + self._max_range - 1, latest)
            try:
                out.extend(self._reader.get_pool_created_events(start, end))
            except ChainError:
                if out:  # hand back what we have; the next poll retries from the cursor
                    break
                raise
            start = end + 1
            self._cursor = start
        return out

    def watch(self, interval: float, stop: Callable[[], bool] = lambda: False) -> Iterator[PoolCreated]:
        """Blocking generator yielding new pools until ``stop()`` returns True."""
        while not stop():
            try:
                yield from self.poll()
            except ChainError as exc:
                log.warning("poll failed: %s", exc)
            time.sleep(interval)
