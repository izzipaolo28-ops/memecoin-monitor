"""Orchestration: watch for pools -> read state -> decide -> guard -> (paper) execute -> report."""
from __future__ import annotations

import json
import logging
import threading
import time
from dataclasses import dataclass
from typing import Callable

from .chain import ChainError, Reader, Watcher
from .config import Config
from .decision import safe_decide
from .executor import Executor
from .models import LaunchRecord, PoolPrice, TokenInfo, short_addr, utcnow
from .risk import apply_guards
from .sinks import ActionEntry, Sink
from .state import build_state

log = logging.getLogger(__name__)
DEFAULT_DECIMALS = 18


def _dec(token: TokenInfo | None) -> int:
    return token.decimals if token is not None and token.decimals is not None else DEFAULT_DECIMALS


@dataclass
class _Pending:
    record: LaunchRecord
    first_seen: float
    loaded: bool = False
    t0: TokenInfo | None = None
    t1: TokenInfo | None = None
    base_is_token0: bool = True
    quote_known: bool = False
    skip_reason: str | None = None


@dataclass
class _Snapshot:
    price: PoolPrice
    pool_liquidity_raw: int | None
    liquidity_quote: float | None


class Bot:
    def __init__(
        self,
        cfg: Config,
        reader: Reader,
        watcher: Watcher,
        decide_fn: Callable[[dict], dict],
        executor: Executor,
        sink: Sink,
        clock: Callable[[], float] = time.monotonic,
    ):
        self.cfg, self.reader, self.watcher = cfg, reader, watcher
        self.decide_fn, self.executor, self.sink, self._clock = decide_fn, executor, sink, clock
        self._pending: dict[str, _Pending] = {}
        self._quote_cache: dict[str, TokenInfo] = {}
        self._quotes = {q.lower() for q in cfg.quote_tokens}
        self._log_path = cfg.data_dir / "actions.jsonl"

    # ---- main loop -------------------------------------------------------------------------
    def run(self, stop: threading.Event, max_steps: int = 0) -> None:
        steps = 0
        while not stop.is_set():
            self.step()
            steps += 1
            if max_steps and steps >= max_steps:
                break
            stop.wait(self.cfg.poll_interval)

    def step(self) -> None:
        self._poll()
        for pool in list(self._pending):
            pending = self._pending[pool]
            try:
                done = self._advance(pending)
            except ChainError as exc:  # transient: retry next step until the pool expires
                pending.record.note = f"rpc error, retrying: {exc}"[:120]
                self.sink.status(error=f"{short_addr(pool)}: {exc}")
                self.sink.launch(pending.record)
                done = self._expired(pending, "rpc errors")
            except Exception as exc:  # a bug: don't retry forever, don't kill the bot
                log.exception("unexpected error processing pool %s", pool)
                done = self._finish(pending, "skip", f"internal error: {exc}", status="error", kind="ERROR")
            if done:
                self._pending.pop(pool, None)
        self._mark_positions()

    # ---- steps -----------------------------------------------------------------------------
    def _poll(self) -> None:
        try:
            events = self.watcher.poll()
        except ChainError as exc:
            self.sink.status(error=f"poll failed: {exc}")
            return
        self.sink.status(block=getattr(self.watcher, "last_block", None), last_poll=utcnow())
        for ev in events:
            record = LaunchRecord(event=ev, detected_at=utcnow())
            self._pending[ev.pool] = _Pending(record=record, first_seen=self._clock())
            self.sink.launch(record)

    def _token(self, address: str) -> TokenInfo:
        if address.lower() in self._quotes:
            if address not in self._quote_cache:
                self._quote_cache[address] = self.reader.read_token(address)
            return self._quote_cache[address]
        return self.reader.read_token(address)

    def _load_tokens(self, p: _Pending) -> None:
        ev = p.record.event
        q0, q1 = ev.token0.lower() in self._quotes, ev.token1.lower() in self._quotes
        t0, t1 = self._token(ev.token0), self._token(ev.token1)  # both succeed before we commit
        if q0 and q1:
            p.skip_reason = "quote/quote pair, not a new token"
        elif q0:
            p.base_is_token0, p.quote_known = False, True
        elif q1:
            p.base_is_token0, p.quote_known = True, True
        else:
            p.base_is_token0, p.quote_known = True, False
        p.t0, p.t1, p.loaded = t0, t1, True
        base = t0 if p.base_is_token0 else t1
        p.record.base_symbol, p.record.base_address = base.symbol, base.address

    def _snapshot(self, p: _Pending) -> _Snapshot:
        ev = p.record.event
        price = self.reader.read_pool_price(ev.pool, _dec(p.t0), _dec(p.t1))
        if not price.initialized:
            return _Snapshot(price, None, None)
        liquidity_quote = None
        if p.quote_known:
            quote = p.t0 if not p.base_is_token0 else p.t1
            balance = self.reader.read_token_balance(quote.address, ev.pool)
            if balance is not None:
                liquidity_quote = balance / 10 ** _dec(quote)
        return _Snapshot(price, self.reader.read_pool_liquidity(ev.pool), liquidity_quote)

    def _advance(self, p: _Pending) -> bool:
        """Returns True when the launch is fully resolved and can leave the pending set."""
        rec = p.record
        if not p.loaded:
            self._load_tokens(p)
        if p.skip_reason:
            return self._finish(p, "skip", p.skip_reason, status="skipped")
        base = p.t0 if p.base_is_token0 else p.t1
        if not base.has_code:
            return self._finish(p, "skip", "token has no bytecode", status="skipped")

        snap = self._snapshot(p)
        rec.liquidity_quote = snap.liquidity_quote
        if not snap.price.initialized:
            waiting = "pool not initialized"
        elif p.quote_known and not (snap.liquidity_quote and snap.liquidity_quote > 0):
            waiting = "no liquidity yet"
        else:
            waiting = None

        if waiting:
            if self._clock() - p.first_seen >= self.cfg.pending_max_age:
                return self._finish(p, "skip", f"expired: {waiting}", status="expired")
            rec.note = f"waiting: {waiting}"
            self.sink.launch(rec)
            return False

        self._decide_and_act(p, snap)
        return True

    def _decide_and_act(self, p: _Pending, snap: _Snapshot) -> None:
        rec, ev = p.record, p.record.event
        state = build_state(
            self.cfg, ev, p.t0, p.t1, p.base_is_token0, p.quote_known,
            snap.price, snap.pool_liquidity_raw, snap.liquidity_quote, rec.detected_at,
        )
        decision, error = safe_decide(state, self.decide_fn)
        guard = apply_guards(decision, state, self.cfg)
        label = rec.base_symbol or short_addr(rec.base_address)

        rec.risk_score = state["risk_score"]
        rec.model_action, rec.model_confidence = decision["action"], decision["confidence"]
        rec.final_action, rec.status = guard.action, "decided"
        notes = []
        if error:
            notes.append(f"decide() failed: {error}")
        if guard.reasons:
            notes.append("buy→skip: " + "; ".join(guard.reasons))
        rec.note = " | ".join(notes)

        if error:
            self._log_action("ERROR", f"{label}: decide() failed, defaulting to skip ({error})", rec)

        if guard.action == "buy":
            try:
                position = self.executor.execute(state, decision)
            except NotImplementedError as exc:
                position = None
                rec.final_action, rec.note = "skip", f"executor: {exc}"
            if position is not None:
                self._log_action(
                    "BUY",
                    f"[{self.executor.mode.upper()}] {label}: {position.size_quote:g} "
                    f"{position.quote_symbol or 'quote'} @ {position.entry_price:.6g} "
                    f"(conf {decision['confidence']:.2f})",
                    rec,
                )
            else:
                rec.final_action = "skip"
                rec.note = rec.note or "executor declined (duplicate or no price)"
                self._log_action("SKIP", f"{label}: {rec.note}", rec)
        else:
            kind = "HOLD" if guard.action == "hold" else "SKIP"
            detail = rec.note or f"engine said {decision['action']} ({decision['confidence']:.2f})"
            self._log_action(kind, f"{label}: {detail}", rec)
        self.sink.launch(rec)

    def _expired(self, p: _Pending, why: str) -> bool:
        if self._clock() - p.first_seen >= self.cfg.pending_max_age:
            return self._finish(p, "skip", f"expired: {why}", status="expired")
        return False

    def _finish(self, p: _Pending, action: str, note: str, status: str, kind: str = "SKIP") -> bool:
        rec = p.record
        rec.final_action, rec.status, rec.note = action, status, note
        label = rec.base_symbol or short_addr(rec.base_address or rec.event.pool)
        self._log_action(kind, f"{label}: {note}", rec)
        self.sink.launch(rec)
        return True

    def _mark_positions(self) -> None:
        for pos in self.executor.open_positions():
            try:
                pp = self.reader.read_pool_price(pos.pool, pos.token0_decimals, pos.token1_decimals)
            except ChainError:
                continue
            price = pp.quote_per_base(pos.base_is_token0)
            if price:
                self.executor.update_price(pos.id, price)
        self.executor.save()
        self.sink.positions(self.executor.open_positions())

    def _log_action(self, kind: str, text: str, rec: LaunchRecord | None = None) -> None:
        entry = ActionEntry(kind=kind, text=text)
        self.sink.action(entry)
        row = {"time": entry.time.isoformat(), "kind": kind, "text": text}
        if rec is not None:
            row.update(pool=rec.event.pool, token=rec.base_address, final_action=rec.final_action)
        try:
            self._log_path.parent.mkdir(parents=True, exist_ok=True)
            with self._log_path.open("a") as fh:
                fh.write(json.dumps(row) + "\n")
        except OSError as exc:
            log.warning("could not write %s: %s", self._log_path, exc)
