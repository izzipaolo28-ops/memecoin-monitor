"""Plain data types shared across modules."""
from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime, timezone


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def short_addr(address: str | None) -> str:
    if not address:
        return "-"
    return f"{address[:6]}…{address[-4:]}" if len(address) > 12 else address


@dataclass(frozen=True)
class PoolCreated:
    """A decoded Uniswap V3 Factory PoolCreated event."""

    pool: str
    token0: str
    token1: str
    fee: int
    tick_spacing: int
    block_number: int
    tx_hash: str
    log_index: int


@dataclass(frozen=True)
class TokenInfo:
    """On-chain facts about an ERC-20 token. Strings come from the token contract and are untrusted."""

    address: str
    has_code: bool
    symbol: str | None = None
    name: str | None = None
    decimals: int | None = None
    total_supply: int | None = None  # raw units
    owner_status: str = "unknown"  # renounced | owned | no_owner_function | unknown
    owner: str | None = None

    @property
    def total_supply_normalized(self) -> float | None:
        if self.total_supply is None or self.decimals is None:
            return None
        return self.total_supply / 10**self.decimals


@dataclass(frozen=True)
class PoolPrice:
    """slot0 snapshot. price_token1_per_token0 is decimal-adjusted; None if the pool is uninitialized."""

    sqrt_price_x96: int
    tick: int
    price_token1_per_token0: float | None

    @property
    def initialized(self) -> bool:
        return self.sqrt_price_x96 != 0

    def quote_per_base(self, base_is_token0: bool) -> float | None:
        p = self.price_token1_per_token0
        if not p or not math.isfinite(p) or p <= 0:
            return None
        out = p if base_is_token0 else 1.0 / p
        return out if math.isfinite(out) and out > 0 else None


@dataclass
class LaunchRecord:
    """One detected pool launch, updated in place as it moves pending -> decided."""

    event: PoolCreated
    detected_at: datetime
    status: str = "pending"  # pending | decided | skipped | expired | error
    base_symbol: str | None = None
    base_address: str | None = None
    liquidity_quote: float | None = None
    risk_score: float | None = None
    model_action: str | None = None
    model_confidence: float | None = None
    final_action: str | None = None
    note: str = ""
