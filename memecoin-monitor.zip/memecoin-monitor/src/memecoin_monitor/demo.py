"""Offline demo backend: synthetic launches so the dashboard and paper executor can be tried
without an RPC connection or a decision model. Nothing here touches the network."""
from __future__ import annotations

import dataclasses
import math
import random

from eth_utils import to_checksum_address

from .config import Config
from .models import PoolCreated, PoolPrice, TokenInfo

DEMO_QUOTE = to_checksum_address("0x" + "00" * 19 + "01")
_SYMBOLS = ["FROGO", "MOONCAT", "DOGEL", "PEPE2", "HOODIE", "STONK", "BAGZ", "WAGMI", "RUGME", "DEGEN9"]


def _rand_addr(rng: random.Random) -> str:
    return to_checksum_address("0x" + rng.getrandbits(160).to_bytes(20, "big").hex())


class DemoReader:
    def __init__(self, seed: int | None = None):
        self.rng = random.Random(seed)
        self.block = 1_000_000
        self._pools: dict[str, dict] = {}
        self._tokens: dict[str, TokenInfo] = {
            DEMO_QUOTE: TokenInfo(DEMO_QUOTE, True, "WETH", "Wrapped Ether", 18, 10**24, "no_owner_function")
        }

    def latest_block(self) -> int:
        return self.block

    def spawn_pool(self) -> PoolCreated:
        rng = self.rng
        token, pool = _rand_addr(rng), _rand_addr(rng)
        has_code = rng.random() > 0.05
        owner = rng.choices(["renounced", "owned", "no_owner_function"], [5, 4, 1])[0]
        self._tokens[token] = TokenInfo(
            token, has_code,
            rng.choice(_SYMBOLS) if has_code else None, "Demo token" if has_code else None,
            18 if has_code else None, (10**9 * 10**18) if has_code else None,
            owner if has_code else "unknown",
        )
        quote_per_base = math.exp(rng.gauss(math.log(1e-7), 1.0))
        self._pools[pool] = {
            "token": token,
            "base_is_token0": int(token, 16) < int(DEMO_QUOTE, 16),
            "price": quote_per_base,
            "reads_until_init": rng.choice([0, 0, 1, 2, 10**6 if rng.random() < 0.15 else 0]),
            "liquidity": math.exp(rng.gauss(math.log(3.0), 1.2)),
        }
        t0, t1 = sorted([token, DEMO_QUOTE], key=lambda a: int(a, 16))
        self.block += 1
        return PoolCreated(pool, t0, t1, rng.choice([500, 3000, 10000]), 60, self.block, f"0x{rng.getrandbits(256):064x}", 0)

    def make_watcher(self, from_block: int | None = None) -> "DemoWatcher":
        return DemoWatcher(self)

    def verify_connection(self) -> int:
        return self.block

    def read_token(self, address: str) -> TokenInfo:
        return self._tokens[address]

    def read_pool_price(self, pool: str, token0_decimals: int, token1_decimals: int) -> PoolPrice:
        p = self._pools[pool]
        if p["reads_until_init"] > 0:
            p["reads_until_init"] -= 1
            return PoolPrice(0, 0, None)
        p["price"] *= math.exp(self.rng.gauss(0, 0.04))  # random walk, quote per base
        # slot0 reports token1 per token0: that is quote/base when base is token0, else base/quote
        price_t1_per_t0 = p["price"] if p["base_is_token0"] else 1.0 / p["price"]
        return PoolPrice(1, 0, price_t1_per_t0)

    def read_pool_liquidity(self, pool: str) -> int | None:
        return 10**18

    def read_token_balance(self, token: str, holder: str) -> int | None:
        p = self._pools.get(holder)
        if token == DEMO_QUOTE and p is not None and p["reads_until_init"] <= 0:
            return int(p["liquidity"] * 10**18)
        return 0


class DemoWatcher:
    def __init__(self, reader: DemoReader):
        self.reader = reader
        self.last_block: int | None = reader.block
        self._first = True

    def poll(self) -> list[PoolCreated]:
        n = 2 if self._first else (1 if self.reader.rng.random() < 0.35 else 0)
        self._first = False
        events = [self.reader.spawn_pool() for _ in range(n)]
        self.reader.block += 1
        self.last_block = self.reader.block
        return events


def demo_decide(state: dict) -> dict:
    """Toy engine for --demo only: confidence falls as the baseline risk score rises."""
    conf = max(0.0, 1.0 - state["risk_score"] / 60.0)
    action = "buy" if conf >= 0.5 else ("hold" if conf >= 0.25 else "skip")
    return {"action": action, "confidence": round(conf, 2)}


def build_demo(cfg: Config, seed: int | None = None):
    """Returns (reader, watcher, decide_fn, cfg) wired for offline demo use."""
    reader = DemoReader(seed)
    demo_cfg = dataclasses.replace(cfg, quote_tokens=(DEMO_QUOTE,), data_dir=cfg.data_dir / "demo")
    return reader, reader.make_watcher(), demo_decide, demo_cfg
