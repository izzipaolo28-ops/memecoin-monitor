"""Baseline risk score and the hard guardrails applied after the decision engine.

The score is a cheap on-chain heuristic, NOT a security audit. It cannot detect honeypots,
transfer taxes, blacklists, hidden mint functions, upgradeable proxies or access-control
admins. Treat it as a coarse filter only.
"""
from __future__ import annotations

from dataclasses import dataclass

from .config import Config

# points added per flag; total is clamped to 0..100
WEIGHTS = {
    "no_bytecode": 100,
    "owner_not_renounced": 25,
    "owner_unknown": 10,
    "decimals_missing": 15,
    "total_supply_unreadable": 20,
    "zero_supply": 30,
    "no_symbol": 5,
    "quote_token_unrecognized": 20,
    "liquidity_unreadable": 10,
    "low_liquidity": 25,
    "no_price": 10,
}


def score_state(state: dict) -> tuple[float, list[str]]:
    base = state["base_token"]
    flags: list[str] = []

    if not base["has_code"]:
        flags.append("no_bytecode")
    else:
        if base["owner_status"] == "owned":
            flags.append("owner_not_renounced")
        elif base["owner_status"] == "unknown":
            flags.append("owner_unknown")
        if base["decimals"] is None:
            flags.append("decimals_missing")
        if base["total_supply_raw"] is None:
            flags.append("total_supply_unreadable")
        elif int(base["total_supply_raw"]) == 0:
            flags.append("zero_supply")
        if not base["symbol"]:
            flags.append("no_symbol")

    if not state["quote_known"]:
        flags.append("quote_token_unrecognized")
    else:
        liq = state["liquidity_quote"]
        if liq is None:
            flags.append("liquidity_unreadable")
        elif liq < state["thresholds"]["min_liquidity"]:
            flags.append("low_liquidity")

    if state["price"] is None:
        flags.append("no_price")

    return float(min(100, sum(WEIGHTS[f] for f in flags))), flags


@dataclass(frozen=True)
class GuardResult:
    action: str
    reasons: tuple[str, ...] = ()


def apply_guards(decision: dict, state: dict, cfg: Config) -> GuardResult:
    """Downgrade a "buy" to "skip" if any hard threshold fails. hold/skip pass through unchanged."""
    if decision["action"] != "buy":
        return GuardResult(decision["action"])

    reasons: list[str] = []
    if decision["confidence"] < cfg.min_confidence:
        reasons.append(f"confidence {decision['confidence']:.2f} < {cfg.min_confidence:g}")
    if state["risk_score"] > cfg.max_risk_score:
        reasons.append(f"risk {state['risk_score']:g} > {cfg.max_risk_score:g}")
    if not state["quote_known"]:
        reasons.append("quote token not in QUOTE_TOKENS")
    if cfg.min_liquidity > 0:
        liq = state["liquidity_quote"]
        if liq is None:
            reasons.append("liquidity unknown")
        elif liq < cfg.min_liquidity:
            reasons.append(f"liquidity {liq:.4g} < {cfg.min_liquidity:g}")
    if state["price"] is None:
        reasons.append("no price")
    if not state["base_token"]["has_code"]:
        reasons.append("no bytecode")

    if reasons:
        return GuardResult("skip", tuple(reasons))
    return GuardResult("buy")
