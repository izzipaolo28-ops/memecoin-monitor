"""Terminal dashboard built on rich: launch feed, decisions, action log and paper positions."""
from __future__ import annotations

import threading
from collections import deque
from datetime import datetime

from rich import box
from rich.console import Console
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .config import Config
from .executor import Position
from .models import LaunchRecord, short_addr
from .sinks import ActionEntry, Sink

KIND_STYLE = {"BUY": "bold green", "HOLD": "yellow", "SKIP": "dim", "INFO": "cyan", "ERROR": "bold red"}
ACTION_STYLE = {"buy": "bold green", "hold": "yellow", "skip": "dim"}
MAX_FEED = 200


def _local(ts: datetime) -> str:
    return ts.astimezone().strftime("%H:%M:%S")


def _num(value: float | None, spec: str = ".4g") -> str:
    return "-" if value is None else format(value, spec)


class Dashboard(Sink):
    """All token-derived strings are rendered via Text(), so '[markup]' in a token name is inert."""

    def __init__(self, cfg: Config, mode: str, console: Console | None = None, demo: bool = False):
        self.cfg, self.mode, self.demo = cfg, mode, demo
        self.console = console or Console()
        self._lock = threading.RLock()
        self._feed: dict[str, LaunchRecord] = {}
        self._actions: deque[ActionEntry] = deque(maxlen=500)
        self._positions: list[Position] = []
        self._st: dict = {"block": None, "last_poll": None, "errors": 0, "last_error": None}
        self._live: Live | None = None

    # ---- Sink interface (called from the bot thread) --------------------------------------
    def __enter__(self):
        self._live = Live(get_renderable=self.render, console=self.console, refresh_per_second=4, screen=True)
        self._live.__enter__()
        return self

    def __exit__(self, *exc) -> None:
        if self._live is not None:
            self._live.__exit__(*exc)

    def launch(self, record: LaunchRecord) -> None:
        with self._lock:
            self._feed[record.event.pool] = record
            while len(self._feed) > MAX_FEED:
                self._feed.pop(next(iter(self._feed)))

    def action(self, entry: ActionEntry) -> None:
        with self._lock:
            self._actions.append(entry)

    def positions(self, positions: list[Position]) -> None:
        with self._lock:
            self._positions = list(positions)

    def status(self, **fields) -> None:
        with self._lock:
            if "error" in fields:
                self._st["errors"] += 1
                self._st["last_error"] = fields["error"]
            for key in ("block", "last_poll"):
                if fields.get(key) is not None:
                    self._st[key] = fields[key]

    # ---- rendering (called from rich's refresh thread) ------------------------------------
    def render(self) -> Layout:
        with self._lock:
            feed = list(reversed(self._feed.values()))
            actions = list(reversed(self._actions))
            positions = list(reversed(self._positions))
            st = dict(self._st)
        rows = max(3, self.console.size.height - 8)

        layout = Layout()
        layout.split_column(Layout(self._header(st), name="header", size=3), Layout(name="body"))
        layout["body"].split_row(Layout(self._feed_panel(feed[:rows]), ratio=3), Layout(name="side", ratio=2))
        layout["side"].split_column(
            Layout(self._actions_panel(actions[:rows]), ratio=3),
            Layout(self._positions_panel(positions[:rows]), ratio=2),
        )
        return layout

    def _header(self, st: dict) -> Panel:
        text = Text()
        text.append("Robinhood Chain monitor", style="bold")
        text.append(f"  chain {self.cfg.chain_id}")
        text.append(f"  block {st['block'] if st['block'] is not None else '-'}")
        text.append(f"  mode {'DEMO (simulated data) ' if self.demo else ''}{self.mode.upper()}", style="bold magenta")
        text.append(f"  poll {self.cfg.poll_interval:g}s")
        if st["last_poll"]:
            text.append(f"  last {_local(st['last_poll'])}")
        if st["errors"]:
            text.append(f"  errors {st['errors']}", style="red")
        if not self.cfg.quote_tokens:
            text.append("  ⚠ QUOTE_TOKENS empty: buys blocked", style="bold yellow")
        text.append("  Ctrl-C quits", style="dim")
        text.truncate(max(10, self.console.size.width - 4), overflow="ellipsis")
        return Panel(text, box=box.ROUNDED, padding=(0, 1))

    def _feed_panel(self, records: list[LaunchRecord]) -> Panel:
        table = Table(expand=True, box=box.SIMPLE_HEAD, pad_edge=False)
        table.add_column("Time", no_wrap=True)
        table.add_column("Token", no_wrap=True, max_width=14, overflow="ellipsis")
        table.add_column("Pool", no_wrap=True)
        table.add_column("Liq", justify="right", no_wrap=True)
        table.add_column("Risk", justify="right", no_wrap=True)
        table.add_column("Model", no_wrap=True)
        table.add_column("Final", no_wrap=True)
        table.add_column("Note", ratio=1, no_wrap=True, overflow="ellipsis")
        for r in records:
            if r.final_action:
                final = Text(r.final_action.upper(), style=ACTION_STYLE.get(r.final_action, ""))
            else:
                final = Text("pending", style="cyan italic")
            model = Text("-" if r.model_action is None else f"{r.model_action} {r.model_confidence:.2f}")
            table.add_row(
                _local(r.detected_at),
                Text(r.base_symbol or short_addr(r.base_address) if r.base_address else "…"),
                short_addr(r.event.pool),
                _num(r.liquidity_quote),
                _num(r.risk_score, ".0f"),
                model,
                final,
                Text(r.note),
            )
        return Panel(table, title="New pool launches · decisions", box=box.ROUNDED)

    def _actions_panel(self, entries: list[ActionEntry]) -> Panel:
        body = Text(no_wrap=True, overflow="ellipsis")
        for i, e in enumerate(entries):
            if i:
                body.append("\n")
            body.append(f"{_local(e.time)} ", style="dim")
            body.append(f"{e.kind:<5} ", style=KIND_STYLE.get(e.kind, ""))
            body.append(e.text)
        if not entries:
            body = Text("waiting for launches…", style="dim")
        return Panel(body, title="Action log", box=box.ROUNDED)

    def _positions_panel(self, positions: list[Position]) -> Panel:
        table = Table(expand=True, box=box.SIMPLE_HEAD, pad_edge=False)
        table.add_column("Token", no_wrap=True, overflow="ellipsis")
        table.add_column("Entry", justify="right", no_wrap=True)
        table.add_column("Last", justify="right", no_wrap=True)
        table.add_column("PnL", justify="right", no_wrap=True)
        table.add_column("Opened", no_wrap=True)
        for p in positions:
            pnl = p.pnl_pct
            style = "" if pnl is None else ("green" if pnl >= 0 else "red")
            table.add_row(
                Text(p.symbol or short_addr(p.token)),
                _num(p.entry_price, ".6g"),
                _num(p.last_price, ".6g"),
                Text("-" if pnl is None else f"{pnl:+.1f}%", style=style),
                _local(datetime.fromisoformat(p.entry_time)),
            )
        return Panel(table, title=f"Paper positions ({len(positions)} open)", box=box.ROUNDED)
