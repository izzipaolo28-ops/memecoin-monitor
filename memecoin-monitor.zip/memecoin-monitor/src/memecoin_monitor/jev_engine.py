"""Jev-backed decision engine. The API key comes from the JEV_API_KEY environment
variable (put it in .env, which is git-ignored). Never hard-code it in this file."""
from __future__ import annotations

import json
import math
import os
import urllib.request

JEV_ENDPOINT = "https://api.typesafe.ai/v1/systemone"

QUESTIONS = {
    "action": {
        "type": "choice",
        "instructions": "Should I enter a position in this token right now?",
        "criteria": {
            "buy": "Strong momentum, healthy buy pressure, acceptable risk",
            "hold": "Not enough signal to act either way",
            "skip": "Red flags outweigh any opportunity here",
        },
    },
    "risk_score": {
        "type": "score",
        "instructions": "Rate rug-pull / scam risk from 1 (safe) to 10 (extreme)",
        "levels": 10,
    },
}


def _ask_jev(state: dict, questions: dict, model: str = "jev-latest") -> dict:
    key = os.environ.get("JEV_API_KEY")
    if not key:
        raise RuntimeError("JEV_API_KEY is not set")
    body = json.dumps({"state": state, "model": model, "questions": questions}).encode()
    req = urllib.request.Request(
        JEV_ENDPOINT,
        body,
        {"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.load(r)["answers"]


def decide(state: dict) -> dict:
    answers = _ask_jev(state, QUESTIONS)
    confidence = float(answers["action"]["confidence"])
    # Reject, don't clamp: if Jev ever returns 0-100 instead of 0-1, clamping would turn
    # every answer into maximum confidence and sail past MIN_CONFIDENCE.
    if not math.isfinite(confidence) or not 0.0 <= confidence <= 1.0:
        raise ValueError(f"confidence {confidence!r} outside 0..1")
    return {
        "action": answers["action"]["choice"],
        "confidence": confidence,
        "risk_score": answers["risk_score"]["score"],  # Jev's 1-10; the bot ignores extra keys
    }
