"""Pluggable decision engine.

:func:`decide` delegates to the Jev engine in ``jev_engine.py`` (swap it for any model). Contract:

    decide(state: dict) -> {"action": "buy" | "hold" | "skip", "confidence": float}

``state`` is JSON-serializable (see ``state.build_state``). Top-level keys::

    chain_id, detected_at, quote_known, price (quote per base), liquidity_quote,
    risk_score (0-100), risk_flags [str], thresholds {min_liquidity, min_confidence, max_risk_score},
    pool        {address, fee, tick_spacing, block_number, tx_hash, base_is_token0,
                 token0_decimals, token1_decimals, tick, liquidity_raw}
    base_token  {address, symbol, name, decimals, total_supply, total_supply_raw,
                 has_code, owner_status, owner}       # the new memecoin
    quote_token {same fields}                          # the token it is paired against

SECURITY: ``symbol`` and ``name`` are strings chosen by whoever deployed the token. If you
pass ``state`` to an LLM, treat them as untrusted input (they can contain prompt injection).

The bot never trusts the return value blindly: it is validated by :func:`validate_decision`,
and any "buy" is still subject to the MIN_CONFIDENCE / MIN_LIQUIDITY / MAX_RISK_SCORE guards.
"""
from __future__ import annotations

import math
from typing import Callable

VALID_ACTIONS = ("buy", "hold", "skip")
SAFE_DEFAULT = {"action": "skip", "confidence": 0.0}


class DecisionError(ValueError):
    """The decision engine returned something outside the contract."""


def stub_decide(state: dict) -> dict:
    """Safe placeholder: always skips. Useful for testing the pipeline without a model."""
    return {"action": "skip", "confidence": 0.0}


def decide(state: dict) -> dict:
    """The engine the bot calls: Jev, via jev_engine.py. Requires JEV_API_KEY in the environment/.env.

    If the key is missing or the call fails, safe_decide() falls back to skip and logs the error.
    """
    from .jev_engine import decide as jev_decide

    return jev_decide(state)


def validate_decision(raw: object) -> dict:
    """Return a clean {"action", "confidence"} dict or raise DecisionError."""
    if not isinstance(raw, dict):
        raise DecisionError(f"decision must be a dict, got {type(raw).__name__}")
    action = raw.get("action")
    if action not in VALID_ACTIONS:
        raise DecisionError(f"action must be one of {VALID_ACTIONS}, got {action!r}")
    conf = raw.get("confidence")
    if isinstance(conf, bool) or not isinstance(conf, (int, float)) or not math.isfinite(conf):
        raise DecisionError(f"confidence must be a finite number, got {conf!r}")
    return {"action": action, "confidence": min(1.0, max(0.0, float(conf)))}


def safe_decide(state: dict, fn: Callable[[dict], dict] = decide) -> tuple[dict, str | None]:
    """Call the engine; on any error or invalid output fall back to skip. Returns (decision, error)."""
    try:
        return validate_decision(fn(state)), None
    except Exception as exc:
        return dict(SAFE_DEFAULT), f"{type(exc).__name__}: {exc}"
