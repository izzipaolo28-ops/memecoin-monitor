"""Output sinks the bot reports to: the rich dashboard, or plain log lines."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from .executor import Position
from .models import LaunchRecord, short_addr, utcnow


@dataclass
class ActionEntry:
    kind: str  # BUY | HOLD | SKIP | INFO | ERROR
    text: str
    time: datetime = field(default_factory=utcnow)


class Sink:
    """No-op base class; subclasses override what they display."""

    def __enter__(self):
        return self

    def __exit__(self, *exc) -> None:
        return None

    def launch(self, record: LaunchRecord) -> None: ...
    def action(self, entry: ActionEntry) -> None: ...
    def positions(self, positions: list[Position]) -> None: ...
    def status(self, **fields) -> None: ...


class PlainSink(Sink):
    """Line-oriented output for logs, pipes and tests."""

    def __init__(self, out=print):
        self._out = out
        self._seen: set[str] = set()

    def launch(self, record: LaunchRecord) -> None:
        ev = record.event
        if ev.pool not in self._seen:
            self._seen.add(ev.pool)
            self._out(
                f"{record.detected_at.astimezone():%H:%M:%S} NEW   pool {short_addr(ev.pool)} "
                f"fee={ev.fee} block={ev.block_number}"
            )
        elif record.status != "pending":
            model = (
                f"{record.model_action}({record.model_confidence:.2f})" if record.model_action else "-"
            )
            self._out(
                f"{record.detected_at.astimezone():%H:%M:%S} DONE  {record.base_symbol or short_addr(record.base_address)} "
                f"liq={_fmt(record.liquidity_quote)} risk={_fmt(record.risk_score)} "
                f"model={model} final={record.final_action} {record.note}".rstrip()
            )

    def action(self, entry: ActionEntry) -> None:
        self._out(f"{entry.time.astimezone():%H:%M:%S} {entry.kind:<5} {entry.text}")

    def status(self, **fields) -> None:
        if "error" in fields:
            self._out(f"{utcnow().astimezone():%H:%M:%S} ERROR {fields['error']}")


def _fmt(value: float | None) -> str:
    return "-" if value is None else f"{value:.4g}"
