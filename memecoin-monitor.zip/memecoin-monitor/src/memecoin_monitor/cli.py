"""Command-line entry point: ``python -m memecoin_monitor`` / ``memecoin-monitor``."""
from __future__ import annotations

import argparse
import logging
import sys
import threading

from .bot import Bot
from .chain import ChainError, ChainReader
from .config import Config, ConfigError
from .dashboard import Dashboard
from .decision import decide
from .demo import build_demo
from .executor import build_executor
from .sinks import PlainSink


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    ap = argparse.ArgumentParser(prog="memecoin-monitor", description=__doc__)
    ap.add_argument("--env-file", help="path to a .env file (default: nearest .env above the cwd)")
    ap.add_argument("--demo", action="store_true", help="simulated launches and a toy decision rule; no network")
    ap.add_argument("--no-dashboard", action="store_true", help="plain log lines instead of the rich dashboard")
    ap.add_argument("--lookback", type=int, default=0, metavar="N", help="also scan the last N blocks at startup")
    ap.add_argument("--steps", type=int, default=0, metavar="N", help="exit after N poll cycles (0 = run forever)")
    ap.add_argument("-v", "--verbose", action="store_true", help="debug logging to stderr")
    return ap.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.WARNING, stream=sys.stderr)

    try:
        cfg = Config.from_env(args.env_file)
    except ConfigError as exc:
        print(f"Config error: {exc}", file=sys.stderr)
        return 2

    if args.demo:
        reader, watcher, decide_fn, cfg = build_demo(cfg)
    else:
        reader = ChainReader(cfg)
        try:
            tip = reader.verify_connection()
        except ChainError as exc:
            print(f"Cannot start: {exc}", file=sys.stderr)
            return 3
        watcher = reader.make_watcher(from_block=max(0, tip - args.lookback) if args.lookback else None)
        decide_fn = decide

    executor = build_executor(cfg)
    plain = args.no_dashboard or args.steps > 0
    sink = PlainSink() if plain else Dashboard(cfg, executor.mode, demo=args.demo)
    bot = Bot(cfg, reader, watcher, decide_fn, executor, sink)

    stop = threading.Event()
    try:
        with sink:
            bot.run(stop, max_steps=args.steps)
    except KeyboardInterrupt:
        pass
    finally:
        executor.save()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
