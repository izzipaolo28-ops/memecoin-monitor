"""Trade execution interface. Only paper trading is implemented; the real swap is a stub."""
from __future__ import annotations

import json
import logging
import os
import uuid
from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass
from pathlib import Path

from .config import Config
from .models import utcnow

log = logging.getLogger(__name__)

SWAP_NOT_IMPLEMENTED = (
    "On-chain swaps are not implemented. Wire a Uniswap V3 SwapRouter call into Executor.swap "
    "(and add key management, slippage limits and a sell-simulation check) before going live."
)


@dataclass
class Position:
    id: str
    pool: str
    token: str
    symbol: str | None
    quote_symbol: str | None
    entry_price: float  # quote-token per base-token
    entry_time: str  # ISO 8601 UTC
    size_quote: float
    quantity: float  # base-token units
    confidence: float
    base_is_token0: bool
    token0_decimals: int
    token1_decimals: int
    last_price: float | None = None
    last_update: str | None = None
    status: str = "open"
    paper: bool = True

    @property
    def pnl_pct(self) -> float | None:
        if not self.last_price or not self.entry_price:
            return None
        return (self.last_price / self.entry_price - 1.0) * 100.0


@dataclass(frozen=True)
class SwapRequest:
    pool: str
    token_in: str
    token_out: str
    amount_in: float  # whole units of token_in
    reference_price: float  # quote per base at decision time
    max_slippage_bps: int = 100


@dataclass(frozen=True)
class SwapResult:
    ok: bool
    price: float | None = None
    amount_out: float | None = None
    tx_hash: str | None = None
    simulated: bool = True
    error: str | None = None


class Executor(ABC):
    mode: str = "abstract"

    @abstractmethod
    def execute(self, state: dict, decision: dict) -> Position | None:
        """Act on an approved "buy". Return the new Position, or None if nothing was opened."""

    @abstractmethod
    def open_positions(self) -> list[Position]: ...

    def update_price(self, position_id: str, price: float) -> None:
        """Mark-to-market hook; default no-op."""

    def save(self) -> None:
        """Persist state; default no-op."""

    def swap(self, request: SwapRequest) -> SwapResult:
        """STUB for the actual on-chain swap."""
        raise NotImplementedError(SWAP_NOT_IMPLEMENTED)


class PaperExecutor(Executor):
    """Simulates fills at the pool's current price (no slippage, fees or gas) and records positions."""

    mode = "paper"

    def __init__(self, size_quote: float, path: Path | None = None):
        self.size_quote = size_quote
        self.path = path
        self._positions: list[Position] = []
        self._load()

    # -- Executor interface --
    def execute(self, state: dict, decision: dict) -> Position | None:
        pool, base, quote = state["pool"], state["base_token"], state["quote_token"]
        price = state.get("price")
        if not price or price <= 0:
            return None
        if any(p.pool == pool["address"] and p.status == "open" for p in self._positions):
            return None  # already holding this pool

        result = self.swap(
            SwapRequest(
                pool=pool["address"],
                token_in=quote["address"],
                token_out=base["address"],
                amount_in=self.size_quote,
                reference_price=price,
            )
        )
        if not result.ok or not result.price or result.amount_out is None:
            return None

        position = Position(
            id=uuid.uuid4().hex[:8],
            pool=pool["address"],
            token=base["address"],
            symbol=base["symbol"],
            quote_symbol=quote["symbol"],
            entry_price=result.price,
            entry_time=utcnow().isoformat(),
            size_quote=self.size_quote,
            quantity=result.amount_out,
            confidence=decision["confidence"],
            base_is_token0=pool["base_is_token0"],
            token0_decimals=pool["token0_decimals"],
            token1_decimals=pool["token1_decimals"],
            last_price=result.price,
            last_update=utcnow().isoformat(),
        )
        self._positions.append(position)
        self.save()
        return position

    def open_positions(self) -> list[Position]:
        return [p for p in self._positions if p.status == "open"]

    def update_price(self, position_id: str, price: float) -> None:
        for p in self._positions:
            if p.id == position_id:
                p.last_price = price
                p.last_update = utcnow().isoformat()
                return

    def swap(self, request: SwapRequest) -> SwapResult:
        return SwapResult(
            ok=True,
            price=request.reference_price,
            amount_out=request.amount_in / request.reference_price,
            simulated=True,
        )

    # -- persistence --
    def save(self) -> None:
        if self.path is None:
            return
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps([asdict(p) for p in self._positions], indent=2))
            os.replace(tmp, self.path)
        except OSError as exc:
            log.warning("could not save positions to %s: %s", self.path, exc)

    def _load(self) -> None:
        if self.path is None or not self.path.exists():
            return
        try:
            self._positions = [Position(**row) for row in json.loads(self.path.read_text())]
        except (OSError, ValueError, TypeError) as exc:
            backup = self.path.with_suffix(".bad")
            log.warning("could not read %s (%s); moving it to %s and starting empty", self.path, exc, backup)
            try:
                os.replace(self.path, backup)
            except OSError:
                pass


class LiveExecutor(Executor):
    """Interface placeholder for real trading. Not usable: swap() is a stub and config rejects MODE=live."""

    mode = "live"

    def execute(self, state: dict, decision: dict) -> Position | None:
        pool, base, quote = state["pool"], state["base_token"], state["quote_token"]
        self.swap(
            SwapRequest(
                pool=pool["address"],
                token_in=quote["address"],
                token_out=base["address"],
                amount_in=0.0,
                reference_price=state["price"],
            )
        )
        return None  # unreachable until swap() is implemented

    def open_positions(self) -> list[Position]:
        return []


def build_executor(cfg: Config) -> Executor:
    if cfg.mode == "paper":
        return PaperExecutor(cfg.paper_position_size, cfg.data_dir / "positions.json")
    raise ValueError(f"unsupported mode {cfg.mode!r}")
