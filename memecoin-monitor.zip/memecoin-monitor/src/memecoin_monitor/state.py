"""Builds the JSON-serializable state dict handed to the decision engine."""
from __future__ import annotations

from datetime import datetime

from .config import Config
from .models import PoolCreated, PoolPrice, TokenInfo
from .risk import score_state


def token_dict(t: TokenInfo) -> dict:
    return {
        "address": t.address,
        "symbol": t.symbol,
        "name": t.name,
        "decimals": t.decimals,
        "total_supply_raw": None if t.total_supply is None else str(t.total_supply),
        "total_supply": t.total_supply_normalized,
        "has_code": t.has_code,
        "owner_status": t.owner_status,
        "owner": t.owner,
    }


def build_state(
    cfg: Config,
    event: PoolCreated,
    token0: TokenInfo,
    token1: TokenInfo,
    base_is_token0: bool,
    quote_known: bool,
    price: PoolPrice,
    pool_liquidity_raw: int | None,
    liquidity_quote: float | None,
    detected_at: datetime,
) -> dict:
    base, quote = (token0, token1) if base_is_token0 else (token1, token0)
    state = {
        "chain_id": cfg.chain_id,
        "detected_at": detected_at.isoformat(),
        "pool": {
            "address": event.pool,
            "fee": event.fee,
            "tick_spacing": event.tick_spacing,
            "block_number": event.block_number,
            "tx_hash": event.tx_hash,
            "base_is_token0": base_is_token0,
            "token0_decimals": token0.decimals if token0.decimals is not None else 18,
            "token1_decimals": token1.decimals if token1.decimals is not None else 18,
            "tick": price.tick if price.initialized else None,
            "liquidity_raw": None if pool_liquidity_raw is None else str(pool_liquidity_raw),
        },
        "base_token": token_dict(base),
        "quote_token": token_dict(quote),
        "quote_known": quote_known,
        "price": price.quote_per_base(base_is_token0),
        "liquidity_quote": liquidity_quote,
        "thresholds": {
            "min_liquidity": cfg.min_liquidity,
            "min_confidence": cfg.min_confidence,
            "max_risk_score": cfg.max_risk_score,
        },
    }
    state["risk_score"], state["risk_flags"] = score_state(state)
    return state
