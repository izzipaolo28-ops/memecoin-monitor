"""Configuration, loaded from environment variables / a .env file."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import find_dotenv, load_dotenv
from eth_utils import is_address, to_checksum_address

DEFAULT_RPC_URL = "https://rpc.mainnet.chain.robinhood.com"
DEFAULT_CHAIN_ID = 4663
DEFAULT_FACTORY = "0x1f7d7550B1b028f7571E69A784071F0205FD2EfA"


class ConfigError(ValueError):
    """Raised when the environment contains an invalid setting."""


def _raw(name: str, default: str | None = None) -> str | None:
    value = os.environ.get(name)
    if value is None or value.strip() == "":
        return default
    return value.strip()


def _number(name: str, default, cast, lo=None, hi=None):
    raw = _raw(name)
    if raw is None:
        return default
    try:
        value = cast(raw)
    except ValueError:
        raise ConfigError(f"{name}={raw!r} is not a valid {cast.__name__}") from None
    if (lo is not None and value < lo) or (hi is not None and value > hi):
        raise ConfigError(f"{name}={value} must be between {lo} and {hi}")
    return value


def _address(name: str, value: str) -> str:
    if not is_address(value):
        raise ConfigError(f"{name}={value!r} is not a valid address (check length and checksum casing)")
    return to_checksum_address(value)


@dataclass(frozen=True)
class Config:
    rpc_url: str = DEFAULT_RPC_URL
    chain_id: int = DEFAULT_CHAIN_ID
    factory_address: str = DEFAULT_FACTORY
    poll_interval: float = 5.0
    max_block_range: int = 2000
    pending_max_age: float = 300.0
    quote_tokens: tuple[str, ...] = ()
    min_liquidity: float = 1.0
    min_confidence: float = 0.7
    max_risk_score: float = 50.0
    mode: str = "paper"
    paper_position_size: float = 0.05
    data_dir: Path = Path("data")

    @classmethod
    def from_env(cls, env_file: str | None = None) -> "Config":
        """Load .env (from `env_file`, else the nearest .env above the cwd), then read settings."""
        load_dotenv(env_file or find_dotenv(usecwd=True), override=False)

        rpc_url = _raw("RPC_URL", DEFAULT_RPC_URL)
        if not rpc_url.startswith(("http://", "https://")):
            raise ConfigError(f"RPC_URL={rpc_url!r} must be an http(s) URL")

        mode = _raw("MODE", "paper").lower()
        if mode != "paper":
            raise ConfigError(f"MODE={mode!r} is not supported: live trading is not implemented, use MODE=paper")

        quote_raw = _raw("QUOTE_TOKENS", "")
        quote_tokens = tuple(
            _address("QUOTE_TOKENS", item.strip()) for item in quote_raw.split(",") if item.strip()
        )

        return cls(
            rpc_url=rpc_url,
            chain_id=_number("CHAIN_ID", DEFAULT_CHAIN_ID, int, lo=1),
            factory_address=_address("UNISWAP_V3_FACTORY", _raw("UNISWAP_V3_FACTORY", DEFAULT_FACTORY)),
            poll_interval=_number("POLL_INTERVAL_SECONDS", 5.0, float, lo=0.1),
            max_block_range=_number("MAX_BLOCK_RANGE", 2000, int, lo=1),
            pending_max_age=_number("PENDING_MAX_AGE_SECONDS", 300.0, float, lo=0.0),
            quote_tokens=quote_tokens,
            min_liquidity=_number("MIN_LIQUIDITY", 1.0, float, lo=0.0),
            min_confidence=_number("MIN_CONFIDENCE", 0.7, float, lo=0.0, hi=1.0),
            max_risk_score=_number("MAX_RISK_SCORE", 50.0, float, lo=0.0, hi=100.0),
            mode=mode,
            paper_position_size=_number("PAPER_POSITION_SIZE", 0.05, float, lo=0.0),
            data_dir=Path(_raw("DATA_DIR", "data")),
        )
