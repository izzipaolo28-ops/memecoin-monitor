"""Robinhood Chain new-pool monitor with a pluggable decision engine and paper trading."""

__version__ = "0.1.0"
