# memecoin-monitor

Watches the Uniswap V3 factory on Robinhood Chain (chain ID 4663) for new pools, reads on-chain facts about each new token, asks a pluggable decision function what to do, and records **paper** trades. No real transactions are ever sent.

```
Uniswap V3 Factory ──PoolCreated──▶ PoolWatcher ─▶ read token + pool state ─▶ risk score
                                                                                  │
 terminal dashboard ◀── launch feed / actions / positions ◀── PaperExecutor ◀─ guards ◀─ decide(state)
```

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt     # runtime deps + pytest
pip install -e .                        # installs the package and the `memecoin-monitor` command

cp .env.example .env                    # then edit it (see "Quote tokens" below)
pytest                                  # first-run sanity check

memecoin-monitor --demo                 # simulated launches, no network, no model needed
memecoin-monitor --lookback 5000 --no-dashboard --steps 3   # first live check: scan the last 5000 blocks, 3 polls
memecoin-monitor                        # live dashboard (Ctrl-C to quit)
```

Without installing, `PYTHONPATH=src python -m memecoin_monitor ...` works too.

Flags: `--demo`, `--no-dashboard` (plain log lines), `--lookback N` (also scan the last N blocks at startup), `--steps N` (exit after N polls), `--env-file PATH`, `-v`.

### Quote tokens (read this first)

A "new memecoin" is whichever token in the pool is **not** a quote token. Set `QUOTE_TOKENS` in `.env` to the addresses of the assets launches are paired against (wrapped ETH, stablecoins). Liquidity is measured as the pool's balance of that token. If `QUOTE_TOKENS` is empty, liquidity is unknown and **every buy is blocked** (the dashboard header warns you). Use addresses you verified yourself; never match on symbol, since anyone can deploy a token named "WETH".

## Configuration (`.env`)

| Variable | Default | Meaning |
|---|---|---|
| `RPC_URL` | `https://rpc.mainnet.chain.robinhood.com` | HTTP JSON-RPC endpoint |
| `CHAIN_ID` | `4663` | Startup aborts if the RPC reports a different chain |
| `UNISWAP_V3_FACTORY` | `0x1f7d…2EfA` | Factory to watch |
| `POLL_INTERVAL_SECONDS` | `5` | Poll period |
| `MAX_BLOCK_RANGE` | `2000` | Blocks per `eth_getLogs` call (auto-splits if the RPC rejects a range) |
| `PENDING_MAX_AGE_SECONDS` | `300` | Give up on a pool that never initializes / never gets liquidity |
| `QUOTE_TOKENS` | empty | Comma-separated quote-token addresses |
| `MIN_LIQUIDITY` | `1.0` | Min pool balance of the quote token, in whole units |
| `MIN_CONFIDENCE` | `0.7` | Min engine confidence for a buy |
| `MAX_RISK_SCORE` | `50` | Max baseline risk score (0 to 100) |
| `MODE` | `paper` | Only `paper` is accepted; `live` is rejected at startup |
| `PAPER_POSITION_SIZE` | `0.05` | Simulated size per buy, in quote-token units |
| `DATA_DIR` | `data` | Output folder (`positions.json`, `actions.jsonl`; demo uses `data/demo/`) |

## Layout

| File (`src/memecoin_monitor/`) | Role |
|---|---|
| `chain.py` | `ChainReader` (PoolCreated logs, `totalSupply` / owner status / bytecode, `slot0` price, pool liquidity) and `PoolWatcher` (block cursor, chunked polling) |
| `decision.py` | **`decide(state) -> {"action", "confidence"}`** stub, plus output validation |
| `risk.py` | Baseline risk score and the post-decision guardrails |
| `state.py` | Builds the JSON-serializable `state` dict |
| `executor.py` | `Executor` interface, `PaperExecutor`, `LiveExecutor` stub, stubbed `swap()` |
| `bot.py` | The loop: poll, hold uninitialized pools as pending, decide, guard, execute, report |
| `dashboard.py`, `sinks.py` | rich dashboard and plain-text output |
| `demo.py` | Offline simulated chain and a toy decision rule (`--demo` only) |
| `config.py`, `cli.py` | `.env` loading and the command line |

## Wiring in your model

`decide()` in `decision.py` delegates to the Jev engine (`jev_engine.py`); set `JEV_API_KEY` in your local `.env`. To use a different model, change the body of `decide()`. `stub_decide()` is an always-skip placeholder. Contract: take `state: dict`, return `{"action": "buy"|"hold"|"skip", "confidence": 0.0-1.0}`. The docstring lists every key in `state` (pool, base/quote token facts, price in quote per base, liquidity, risk score and flags, thresholds).

- Output is validated. Exceptions, bad actions or non-finite confidence become `skip` / `0.0` and show in the action log.
- A `buy` still has to pass `MIN_CONFIDENCE`, `MIN_LIQUIDITY`, `MAX_RISK_SCORE`, a known quote token and a readable price. Otherwise it is downgraded to `skip`, and the feed shows both the model's answer and the final action. The model cannot bypass these.
- **Token `name` / `symbol` are written by the token's deployer.** If you forward `state` to an LLM, treat them as untrusted input (prompt injection). They are control-character-stripped and length-capped, and rendered inert in the dashboard, but not sanitized for prompts.
- `decide()` is called synchronously. A slow model delays the loop but never loses events: the block cursor catches up.
- A pool is evaluated once it is initialized and has quote-token liquidity. Many launches initialize or add liquidity a block or two after `PoolCreated`, so they wait as `pending` in the feed.

## Paper trading

On an approved `buy`, `PaperExecutor` simulates a fill at the pool's current price (no slippage, fees or gas), stores a `Position` (entry price, UTC timestamp, size, quantity, confidence) in `data/positions.json`, and marks it to market each poll. One open position per pool.

`Executor.swap(SwapRequest) -> SwapResult` is the stubbed on-chain call: it raises `NotImplementedError`. `LiveExecutor` shows the shape, and `config.py` refuses `MODE=live`.

## Limitations, and what to add before any real trading

- The risk score is a coarse on-chain heuristic (ownership, supply, decimals, liquidity). It cannot see honeypots, transfer taxes, blacklists, hidden mints, proxies or role-based admins. Simulating a sell is the obvious next safeguard.
- "No `owner()` function" is not "no admin".
- Reads assume a standard Uniswap V3 pool (`slot0` layout). Forks with a different layout need a different decoder.
- Plain HTTP polling; no websockets or reorg handling beyond re-reading from the cursor.
- A live executor needs key management, slippage and size limits, and a kill switch.
- Only the Robinhood Chain reader exists. `Reader` / `Watcher` in `chain.py` are the interfaces a Solana (or other) backend would implement.

## Tests

`pytest` covers price math, event and token decoding, the watcher cursor, risk and guards, the decision contract, the paper executor, config validation, and the bot loop (using fake readers).
